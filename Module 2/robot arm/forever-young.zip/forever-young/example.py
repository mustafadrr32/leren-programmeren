


# from RobotArm import RobotArm
# robotArm = RobotArm('exercise 6')

# robotArm.moveRight()
# robotArm.grab()
# robotArm.moveLeft()
# robotArm.drop()
# robotArm.moveRight()
# robotArm.grab()
# robotArm.moveRight()
# robotArm.drop()
# robotArm.moveLeft()
# robotArm.grab()
# robotArm.moveLeft()
# robotArm.drop()
# robotArm.moveRight()
# robotArm.grab()
# robotArm.moveRight()
# robotArm.drop()
# robotArm.moveLeft()
# robotArm.grab()
# robotArm.moveLeft()
# robotArm.drop()
# robotArm.moveRight()
# robotArm.grab()
# robotArm.moveRight()
# robotArm.drop()



# robotArm.wait()

# <<------ oefening 6 --->




